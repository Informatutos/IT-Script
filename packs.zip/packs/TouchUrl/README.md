# TouchUrl
Website Basic Work
Author 
: EPIC
# Installtion 
1. git clone https://github.com/SkyKnight-Team/TouchUrl.git
2. cd TouchUrl

3. ls
4. chmod +x install.sh
5. chmod +x touchurl.py
 
6. sh install.sh

7. clear 
8. python touchurl.py
 
# Start Now
