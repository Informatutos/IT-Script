#!/usr/bin/python
#This Tool Only For Educational Purpose.
#Please Don't illegal work.
#It's Your Own Risk.
import os, sys, time
from colorama import Fore, Back, init
import urllib.parse
from urllib.request import urlopen
import string as s
a = s.ascii_letters
b = s.digits
c = s.punctuation
os.system("clear")
logo = '''
  ______                 __    __  __     __
 /_  __/___  __  _______/ /_  / / / /____/ /
  / / / __ \/ / / / ___/ __ \/ / / / ___/ / 
 / / / /_/ / /_/ / /__/ / / / /_/ / /  / /  
/_/  \____/\__,_/\___/_/ /_/\____/_/  /_/
'''+Fore.MAGENTA+"  TouchUrl | Encode | Decode | Clone "




about = '''
Author       : EPIC
Team         : SkyKnight
Email        : epic.skyknight@gmail.com

Tool Name    : TouchUrl
Tool Version : v1.0
Date & Time  : 01/05/2018 -- 9:22 PM
'''
print(Fore.BLUE+logo)
print(Fore.YELLOW+about+"\n_______________________________________")
print(" ")
print(Fore.BLUE+"[1] Website Home Page Clone \n[2] Url Decode \n[3] Url Encode \n[4] HTTack \n[u] update \n[e] exit \n")
choose = input(Fore.RED+"[SkyKnight"+Fore.BLUE+"@"+Fore.GREEN+"TouchUrl]~ ")
if choose == '01' or choose == '1':
    print(Fore.MAGENTA+" Path Set Example : "+Fore.GREEN+"/sdcard/clone.html\n"+Fore.MAGENTA+"Path Set Example :"+Fore.GREEN+"/Desktop/clone.html\n")
    path = input(Fore.GREEN+"Path|Set ~ "+Fore.YELLOW+"")
    if path not in a+b+c:
        website = input(Fore.RED+"[!] WITH https:// OR http:// : "+Fore.YELLOW+"")
        ur = urlopen(website).read().decode('utf-8')
        f = open(path,"w")
        f.write(ur)
        print(Fore.GREEN+" Successfully Cloning Url.")
        init(autoreset=True)
        sys.exit()
    else:
        sys.exit()
        init(autoreset=True)
elif choose == '02' or choose == '2':
    url = input(Fore.GREEN+"[+] SkyKnight$Url >> ")
    a = urllib.parse.unquote_plus(url)
    print(Fore.GREEN+"\n[+] Decode Url : "+Fore.YELLOW+a)
    b = urllib.parse.unquote(url)
    print(Fore.GREEN+"\n[+] Decode Url : "+Fore.YELLOW+b)
    init(autoreset=True)
elif choose == '03' or choose == '3':
    a = input(Fore.YELLOW+"[+] SkyKnight$Url >> "+Fore.GREEN+"")
    b = urllib.parse.quote_plus(a)
    print(Fore.GREEN+"\n[-] Encode Url : "+Fore.YELLOW+b)
    c = urllib.parse.quote(a)
    print(Fore.GREEN+"\n[-] Encode Url : "+Fore.YELLOW+c) 
    init(autoreset=True)
elif choose == 'e' or choose == 'exit':
    sys.exit()
    init(autoreset=True)
elif choose == 'u' or choose == 'update':
    os.system("cd ~")
    os.system("rm -rf TouchUrl")
    os.system("git clone https://github.com/SkyKnight-Team/TouchUrl.git")
    print(Fore.GREEN+" UPDATE TouchUrl.")
    init(autoreset=True)
elif choose == '4' or choose == '04':
    os.system("pip install wget")
    os.system("apt install wget -y")
    os.system("clear")
    httrack = input("Website @+:- ")
    os.system("wget -mk "+httrack)
    print(" Done!")
    
else:
    print(Fore.RED+"[!] Wrong Enter.")
    init(autoreset=True)