apt-get update
apt install python python2 -y
pip install --upgrade pip
pip2 install --upgrade pip
pip install colorama
