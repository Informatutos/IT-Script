# Lazymux
![Lazymux](https://github.com/Gameye98/Lazymux/core/lazymux.png)<br>
Lazymux tools installer is very easy to use, only provided for lazy termux users.

### Requirements
• Python 2.x

#### Installation and Using Lazymux
```
git clone https://github.com/Gameye98/Lazymux
```
```
cd Lazymux
```
```
python2 lazymux.py
```

## Donation
Support me with your donation<br>
BTC:<br>
```
*. 1Eej5chjFzmdJdnQTfnTHeMQBYg5NPZ2Wm
```
DOGEcoin:<br>
```
*. DKNQfy2u4RTm4hAurUq67hkHLqdoVhD4fN
```
